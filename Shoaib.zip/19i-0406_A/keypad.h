//============================================================================
// Project     : Keypad.h
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================

#ifndef KEYPAD_H_
#define KEYPAD_H_
#include<iostream>
#include<string>
#include<cmath>
#include<cstdlib>
#include"Account.h"
using namespace std;
class Keypad:public Acount
{

public:
          Keypad():Acount(){};
        
          void List();
          bool compare();
          void Menu1();
          void Menu2();       
          void withdraw();
          void Deposit();

};
#endif 