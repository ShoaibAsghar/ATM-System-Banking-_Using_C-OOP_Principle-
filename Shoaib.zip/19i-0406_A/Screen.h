//============================================================================
// Project     : Screen.h
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================

#ifndef SCREEN_H_
#define SCREEN_H_
#include"keypad.h"
#include"Bank_Inquiry.h"
#include<iostream>
#include<string>
#include<cmath>
#include<cstdlib>
using namespace std;
class Screen:public Keypad
{
 
public:
        Screen():Keypad(){}            //Default Constructor
        void Start();
        void Menu();
};
#endif 