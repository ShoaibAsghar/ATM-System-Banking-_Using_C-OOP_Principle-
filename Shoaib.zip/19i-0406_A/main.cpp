//============================================================================
// Project     : main.cpp
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================

#include<iostream>
#include<string>
#include<cstring>
#include<fstream>
#include<iomanip>
#include<cstdlib>  
#include"Account.cpp" 
#include"keypad.cpp"  
#include"BankData.h"  
#include"BankData.cpp"  
#include"Screen.cpp"  
#include"Bank_Inquiry.cpp"
using namespace std;
int main()
{  
                   //File write the user account number, pin number and total balance  
  ofstream Outfil;
	Outfil.open("Bank_data.txt",ios::out);
	Outfil<<5000<<endl;	  //Total Amount in ATM
	Outfil<<98765<<endl;	// Account Number
	Outfil<<12345<<endl;  // Acount PIN  
  Outfil.close();

    Screen TEST;        //Call SCreen to start the functionality    
    TEST.Start();

    Database TEST2;
    TEST2.Update();
    TEST2.Trans();
    return 0;       
 
}