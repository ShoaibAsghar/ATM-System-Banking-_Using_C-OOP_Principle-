//============================================================================
// Project     : BankInquery.cpp
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================


#include <iostream>
#include <fstream>       
using namespace std;
#include"Bank_Inquiry.h"

void BankInquiry::Balance()                 //Show the Current Balance of the User from DataBase
     {
               int Balan;
               fstream infile;       
               infile.open("Bank_data.txt",ios::in);     
               infile>>Balan;
               cout<<"Your Current Balance is: "<<Balan<<endl;
               infile.close(); 
     }          