//============================================================================
// Project     : Keypad.cpp
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================

#include <iostream>
#include <fstream> 
#include"keypad.h"
#include"BankData.h"
#include"Bank_Inquiry.h"

void Keypad::List()             //Function for Reciepcient List
     {
       cout<<"Thank You For using ATM!"<<endl<<endl;
       cout<<"Your Account Number: "<<Acc_Number<<endl;
       cout<<"Your Remaining Balance is "<<Total_Notes<<endl;
     }

bool Keypad::compare()   //Function which campare the Bank Database file with User enter Account and Pin
     {
       int pin,account_num;
       double total_amount;
       bool flag1;
       fstream infile;
      
       infile.open("Bank_data.txt",ios::in);  
      
       infile>>total_amount;
       infile>>account_num;
       infile>>pin;
       infile.close();
        
       if(Acc_Number==account_num && Pin==pin) 
         {
           flag1=true;
           return flag1;
         }
       else
        {
         flag1=false;
         return flag1;
        }

     }

void Keypad::Menu1()     //Display the Menu  
     {
      
       cout<<"WELCOME TO ATM!"<<endl<<endl;
       int total_N=500;
       bool Flag;
       cout<<"Enter Your 5 Digit Account Number: ";
       cin>>Acc_Number;
       
   
       if(Acc_Number<0 || Acc_Number>99999)
        {
         cout<<"Error!Please Enter Your 5 Digit Account Number Again: ";
         cin>>Acc_Number;  
         while(Acc_Number<0 || Acc_Number>99999)
             {
              cout<<"Error!Please Enter Your 5 Digit Account Number Again: ";
              cin>>Acc_Number;  
             }
        }

       cout<<"Enter Your 5 digit Pin Number: ";
       cin>>Pin;
        
           if(Pin<0 || Pin>99999)
              {
                cout<<"Error!Please Enter Your 5 Digit Pin Number Again: ";
                cin>>Pin;  
               while(Pin<0 || Pin>99999)
                    {
                     cout<<"Error!Please Enter Your 5 Digit Pin Number Again: ";
                     cin>>Pin;  
                    }
              } 
             
         Total_Amount=5000;  
        
         Flag=compare();

           if(Flag==true)
            {
             Menu2();
           }  

        else if(Flag==false)   
                   {
                    Menu1();
                   
                   }  

     }
void Keypad::Menu2()         //Function to Display the Menu2
     {
        
       int choice; 
       int Bal;  
       cout<<"MENU: "<<endl<<endl;
       cout<<"      1- View my balance "<<endl;
       cout<<"      2- Withdraw Cash "<<endl;
       cout<<"      3- Deposit Fund "<<endl;
       cout<<"      4- Exit "<<endl;
       cout<<"Enter your Choice: ";
       cin>>choice;
       switch (choice)
       {
       case 1:
             {  
                 BankInquiry test;
                 test.Balance();
                 Menu1(); 
             }
           break;
        case 2:
               {
                 withdraw();
               }
           break;

        case 3:
               {
                 Deposit();  
               }  
           break;  

        case 4:
               {
                 cout<<"Thank You For using ATM !"<<endl; 
                  Menu1();
               }
          break;          
       default:
               {
                 cout<<"Please Enter correct choice!"<<endl;
                 Menu2(); 
               }
           break;
       }

     }   

void  Keypad::withdraw()     //Withdraw Function to implement the withdraw Functionality
     {
       int chose;
       int with_D;
       cout<<"Withdraw Options:"<<endl;
       cout<<"                  1- 20$ "<<endl;
       cout<<"                  2- 40$ "<<endl;
       cout<<"                  3- 60$ "<<endl;
       cout<<"                  4- 100$ "<<endl;
       cout<<"                  5- 200$ "<<endl;
       cout<<"                  6- Cancel Transection "<<endl<<endl;
       cout<<"Choose a Withdrawal Option (1 - 6):"<<endl;
       cin>>chose;
       switch (chose)
       {
       case 1:
             { 
               with_D=20;
              if(with_D > Total_Amount)
                   {
                     cout<<"Your Acount does not have enough money! please choose smaller withdraw amount!"<<endl;
                     Menu1();
                   }

              if(with_D <= Total_Amount)
                 { 
                  cout<<"Your Withdrawal Amount is "<<with_D<<"$"<<endl;
                  Total_Amount=Total_Amount-with_D;
                  Total_Notes=Total_Notes - 1;
                  cout<<"Your Remaining Balance is "<<Total_Amount<<endl<<endl;
                  if(Total_Amount>20 && Total_Notes>=1)
                     {
                       cout<<"You can Perform any other transection!"<<endl;
                       withdraw();
                     } 
                  
                  else if(Total_Notes==0)
                         {
                           cout<<"Sorry ATM Does not Have Enough Cash to Fullfil the Desired transection!"<<endl;
                           withdraw();
                         }

                 }
                 
                 
             }
         break;
       
       case 2:
             { 
              with_D=40;
              if(with_D > Total_Amount)
                   {
                     cout<<"Your Acount does not have enough money! please choose smaller withdraw amount!"<<endl;
                     Menu1();
                   }

              if(with_D <= Total_Amount)
                 { 
                  cout<<"Your Withdrawal Amount is "<<with_D<<"$"<<endl;
                  Total_Amount=Total_Amount-with_D;
                  Total_Notes=Total_Notes - 2;
                  cout<<"Your Remaining Balance is "<<Total_Amount<<endl;
                  
                  if(Total_Amount>20 && Total_Notes>=2)
                     {
                       cout<<"You can Perform any other transection!"<<endl;
                       withdraw();
                     } 
                  
                  else if(Total_Notes==0)
                         {
                           cout<<"Sorry ATM Does not Have Enough Cash to Fullfil the Desired transection!"<<endl;
                           withdraw();
                         }

                 }

             }
         break; 

       case 3:
            {  
               with_D=60;
               if(with_D > Total_Amount)
                   {
                     cout<<"Your Acount does not have enough money! please choose smaller withdraw amount!"<<endl;
                     Menu1();
                   }

              if(with_D <= Total_Amount)
                 { 
                  cout<<"Your Withdrawal Amount is "<<with_D<<"$"<<endl;
                  Total_Amount=Total_Amount-with_D;
                  Total_Notes=Total_Notes - 3;
                  cout<<"Your Remaining Balance is "<<Total_Amount<<endl;
 
                  if(Total_Amount>20 && Total_Notes>=3)
                     {
                       cout<<"You can Perform any other transection!"<<endl;
                       withdraw();
                     } 
                  
                  else if(Total_Notes==0)
                         {
                           cout<<"Sorry ATM Does not Have Enough Cash to Fullfil the Desired transection!"<<endl;
                           withdraw();
                         }
                 }

             }
         break; 

       case 4:
            {  
              with_D=100;
              if(with_D > Total_Amount)
                   {
                     cout<<"Your Acount does not have enough money! please choose smaller withdraw amount!"<<endl;
                     Menu1();
                   }

              if(with_D <= Total_Amount)
                 { 
                  cout<<"Your Withdrawal Amount is "<<with_D<<"$"<<endl;
                  Total_Amount=Total_Amount-with_D;
                  Total_Notes=Total_Notes - 5;
                  cout<<"Your Remaining Balance is "<<Total_Amount<<endl;

                  if(Total_Amount>20 && Total_Notes>=5)
                     {
                       cout<<"You can Perform any other transection!"<<endl;
                       withdraw();
                     } 
                  
                  else if(Total_Notes==0)
                         {
                           cout<<"Sorry ATM Does not Have Enough Cash to Fullfil the Desired transection!"<<endl;
                           withdraw();
                         }

                 } 

             }
         break; 

       case 5:
             {
               with_D=200;
              if(with_D > Total_Amount)
                   {
                     cout<<"Your Acount does not have enough money! please choose smaller withdraw amount!"<<endl;
                     Menu1();
                   }

              if(with_D <= Total_Amount)
                 { 
                  cout<<"Your Withdrawal Amount is "<<with_D<<"$"<<endl;
                  Total_Amount=Total_Amount-with_D;
                  Total_Notes=Total_Notes - 10;
                  cout<<"Your Remaining Balance is "<<Total_Amount<<endl;
 
                  if(Total_Amount>20 && Total_Notes>=10)
                     {
                       cout<<"You can Perform any other transection!"<<endl;
                       withdraw();
                     } 
                  
                  else if(Total_Notes==0)
                         {
                           cout<<"Sorry ATM Does not Have Enough Cash to Fullfil the Desired transection!"<<endl;
                           withdraw();
                         }

                 } 

             }
         break;     
       
       case 6:
              {
                Menu2();
              }
         break;   

       default:
               {
                 cout<<"Error!Please Enter Correct choice "<<endl;
                 withdraw();
               }
         break;
       }

        

     }        


void  Keypad::Deposit()        //Deposit Function to implement the Deposit Functionality
      {
        int Depost;
        cout<<"Deposit: "<<endl;
        cout<<"How much You Deposit the money: ";
        cin>>Depost;
        cout<<"Enter Your Deposit Envelop in Deposit Slot"<<endl;
        Total_Amount=Total_Amount+Depost;
        cout<<"Your Current Balnce is "<<Total_Amount<<endl<<endl;
        cout<<"You can Perform any other transection!"<<endl;
        Menu2();
        
      }

   