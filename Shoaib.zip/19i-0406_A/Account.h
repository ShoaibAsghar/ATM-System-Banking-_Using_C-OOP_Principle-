//============================================================================
// Project     : Account.h
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================

#ifndef ACCOUNT_H_
#define ACCOUNT_H_
#include<iostream>
#include<string>
#include<cmath>
#include<cstdlib>
using namespace std;
class Acount
{
protected:
           double Total_Amount;
           int Acc_Number,Pin;
           int Total_Notes;
public:
           Acount();             
           Acount(int Acc_N,int Pi,int T_Not,double total);
           double  getTotal_Amount();
           void setTotal_Amount(double Total_Am);
           int  getAcc_Number();
           int  getPin();
           int  getTotal_Notes();
           void setAcc_Number(int acount_N);
           void setPin(int P);
           void setTotal_Notes(int N);
          

};
#endif 