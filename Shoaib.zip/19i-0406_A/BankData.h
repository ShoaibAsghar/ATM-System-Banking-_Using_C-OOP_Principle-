//============================================================================
// Project     : BankData.h
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================

#ifndef DATABASE_H_
#define DATABASE_H_
#include"keypad.h"
#include<iostream>
#include<string>
#include<cmath>
#include<cstdlib>
using namespace std;
class Database:public Keypad
{
 
public:
        Database():Keypad(){}
        void Update();
        void Trans();
};
#endif 