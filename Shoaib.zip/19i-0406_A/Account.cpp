//============================================================================
// Project     : Account.cpp
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================

#include <iostream>
#include <fstream> 
#include"keypad.h"
#include"Account.h"

Acount::Acount()              //Default Constractor
      {

        Acc_Number=0;
        Pin=0;
        Total_Notes=500;
        Total_Amount=5000; 

      }

Acount::Acount(int Acc_N,int Pi,int T_Not,double total)      //Parameterized Constractor
      {
        Acc_Number=Acc_N;
        Pin=Pi;
        Total_Notes=T_Not;
        Total_Amount=total;   

      }     

double Acount::getTotal_Amount()          //Excessor Function
    {
      return Total_Amount;
    }

void Acount::setTotal_Amount(double Total_Am)     //setter Function
     {
       Total_Amount=Total_Am;  
     } 

int Acount::getAcc_Number()                      //Excessor Function
    {
      return Acc_Number;
    }

int Acount::getPin()                            //Excessor Function
    {
      return Pin;
    }

int  Acount::getTotal_Notes()                  //Excessor Function
     {
       return Total_Notes;
     }

void Acount::setAcc_Number(int acount_N)      //setter Function     
     {
       Acc_Number=acount_N;  
     }   

void Acount::setPin(int P)                   //setter Function
     {
       Pin=P;  
     } 

void Acount::setTotal_Notes(int N)           //setter Function
     {
       Total_Notes=N;
     }

