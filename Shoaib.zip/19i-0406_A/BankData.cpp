//============================================================================
// Project     : BankData.cpp
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================

#include <iostream>
#include <fstream>       
using namespace std;
#include"keypad.h"
#include"BankData.h"

void Database::Update()         //Update the DataBase File Aftr transection
     {
       
       ofstream outfile;     
       outfile.open("Bank_data.txt",ios::in);   
       outfile<<Total_Amount<<endl;    //Total Balance
       outfile<<Acc_Number<<endl;	    // Account Number
       outfile<<Pin<<endl;           //  Acount PIN  
       outfile.close();  
       
     }

void Database::Trans() 
     {
       string Date;
       Date="26/10/2020";
       ofstream Outfile;     
       Outfile.open("Transection.txt",ios::in); 
       Outfile<<Acc_Number<<endl;	              // Account Number  
       Outfile<<Total_Amount<<endl;             //Total Balance
       Outfile<<Date<<endl;                     //Date

       Outfile.close();  

     }
