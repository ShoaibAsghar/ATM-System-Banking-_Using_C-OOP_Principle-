//============================================================================
// Project     : Screen.cpp
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================

#include <iostream>
#include <fstream>       
using namespace std;
#include"keypad.h"
#include"Screen.h"
void Screen::Start()                  //Start the Program where Initial ATM show the program 
{

       cout<<"WELCOME TO ATM!"<<endl<<endl;
       int total_N=500;
       bool Flag1;
       cout<<"Enter Your 5 Digit Account Number: ";
       cin>>Acc_Number;
       
   
       if(Acc_Number<0 || Acc_Number>99999)                //Input validation
        {
         cout<<"Error!Please Enter Your 5 Digit Account Number Again: ";
         cin>>Acc_Number;  
         while(Acc_Number<0 || Acc_Number>99999)
             {
              cout<<"Error!Please Enter Your 5 Digit Account Number Again: ";
              cin>>Acc_Number;  
            }
        }

       cout<<"Enter Your 5 digit Pin Number: ";
       cin>>Pin;
         
            if(Pin<0 || Pin>99999)                         //Input validation
              {
                cout<<"Error!Please Enter Your 5 Digit Pin Number Again: ";
                cin>>Pin;  
               while(Pin<0 || Pin>99999)
                    {
                     cout<<"Error!Please Enter Your 5 Digit Pin Number Again: ";
                     cin>>Pin;  
                    }
              }            
       
         Total_Amount=5000; 
         
         Flag1=compare();

           if(Flag1==true)
            {
             Menu();
           }  

        else if(Flag1==false)   
                   {
                    Start();
                   }     

}

void Screen::Menu()                      //Funtion to Display the Main Menu
     {
       int choice; 
       int Bal;  
       cout<<"MENU: "<<endl<<endl;
       cout<<"      1- View my balance "<<endl;
       cout<<"      2- Withdraw Cash "<<endl;
       cout<<"      3- Deposit Fund "<<endl;
       cout<<"      4- Exit "<<endl;
       cout<<"Enter your Choice: ";
       cin>>choice;
       switch (choice)
       {
       case 1:
             {  
               BankInquiry test;
               test.Balance();
               Start();
                
             }
           break;
        case 2:
               {
                 withdraw();
               }
           break;

        case 3:
               {
                 Deposit();  
               }  
           break;  

        case 4:
               {
                 cout<<"Thank You For using ATM !"<<endl; 
                 Start();
               }
               break;          
       default:
               {
                 cout<<"Please Enter correct choice!"<<endl;
                 Menu(); 
               }
           break;
       }

     }
     
     