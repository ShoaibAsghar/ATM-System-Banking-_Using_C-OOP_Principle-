//============================================================================
// Project     : BankInquery.h
// Name        : Shoaib Asghar
// Rol No      : 19I-0406
// Section     : A
//============================================================================

#ifndef BANKINQUIRY_H_
#define BANKINQUIRY_H_
#include<iostream>
#include<string>
#include<cmath>
#include<cstdlib>
using namespace std;
class BankInquiry
{
 
public:
        BankInquiry(){}         //Default Constructor
        void Balance();
};
#endif 